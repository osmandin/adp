Custom Document similarity measures, to be put in
src/java/org/apache/lucene/search/similar.
