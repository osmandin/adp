/*
 * HDFType.java
 *
 * Created on February 24, 2002, 2:37 PM
 */

package org.apache.poi.hdf.model.hdftypes;

/**
 *
 * @author  andy
 */
public interface HDFType {

}

