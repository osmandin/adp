Welcome to Apache Camel
========================== 
Apache Camel is a POJO Routing Engine and Mediation Framework


Getting Started
===============
To help you get started, try the following links:-

Getting Started
  http://activemq.apache.org/camel/getting-started.html

Building
  http://activemq.apache.org/camel/building.html

We welcome contributions of all kinds, for details of how you can help
  http://activemq.apache.org/contributing.html

Please refer to the website for details of finding the issue tracker, email lists, wiki or IRC channel
  http://activemq.apache.org/camel/

If you hit any problems please talk to us on the Camel Forums
  http://activemq.apache.org/camel/discussion-forums.html

Please help us make Apache Camel better - we appreciate any feedback you may have.
Enjoy!

------------------------
The Camel riders!
