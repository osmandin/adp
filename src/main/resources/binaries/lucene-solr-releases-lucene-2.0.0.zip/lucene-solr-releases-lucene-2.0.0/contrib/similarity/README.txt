Document similarity measures. 
This most significant contribution here is MoreLikeThis,
in /src/java/org/apache/lucene/search/similar.
